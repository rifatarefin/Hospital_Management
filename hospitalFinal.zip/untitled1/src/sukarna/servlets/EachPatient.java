package sukarna.servlets;

import sukarna.db.DataAccess;
import sukarna.models.patient;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by Rifat Arefin on 16-Dec-16.
 */
@WebServlet(name = "EachPatient")
public class EachPatient extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session= request.getSession();
        DataAccess db = new DataAccess();
        String uid= (String) session.getAttribute("username");
        String pid=request.getParameter("pid");
        System.out.println(pid+"spoi");
        ArrayList<patient> patients= new ArrayList<>();
        String q= "select record_id,doctor_id,patient_id,Appointment_date, description from PATIENT_RECORD where PATIENT_ID= ?";
        try {
            PreparedStatement stmt= db.conn.prepareStatement(q);
            stmt.setString(1,pid);
            //patient p = new patient();
            ResultSet rs= stmt.executeQuery();
            while (rs.next())
            {
                patient p = new patient();
                p.pid= rs.getInt(3);
                String s=""+p.pid;
                p.appoint= rs.getString(4);
                p.des= rs.getString(5);
                p.rid= rs.getInt(1);
                p.did= rs.getInt(2);
                String d= ""+p.did;
                q="SELECT name from patient where patient_id =?";
                stmt= db.conn.prepareStatement(q);
                stmt.setString(1,s);
                ResultSet rs1= stmt.executeQuery();
                if(rs1.next())
                {
                    p.name=rs1.getString(1);
                    q="SELECT name from employee where staff_id =?";
                    stmt= db.conn.prepareStatement(q);
                    stmt.setString(1,d);
                    rs1= stmt.executeQuery();
                    if(rs1.next())
                    {
                        p.dname=rs1.getString(1);
                    }
                }
                System.out.println(p.pid+"id"+p.name);
                patients.add(p);

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        session.setAttribute("ttp",patients);
        RequestDispatcher rd = request.getRequestDispatcher("EachPatient.jsp");
        rd.forward(request, response);


    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        processRequest(request,response);
    }
}
