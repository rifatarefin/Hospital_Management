/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sukarna.servlets;

import org.omg.CORBA.portable.OutputStream;
import sukarna.db.DataAccess;
import sukarna.models.patient;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Blob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author samsung
 */
public class seerecord extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session= request.getSession();

        String uid= (String) session.getAttribute("username");
        System.out.println(uid);
        DataAccess db = new DataAccess();
        patient p = new patient();
        String q= "select record_id,doctor_id,Appointment_date, description from patient_record where patient_id= ?";
        try {
            PreparedStatement stmt= db.conn.prepareStatement(q);
            stmt.setString(1,uid);
            ResultSet rs= stmt.executeQuery();
            if (rs.next())
            {
                p.pid= Integer.parseInt(uid);
                p.appoint= rs.getString(3);
                p.des= rs.getString(4);
                p.rid= rs.getInt(1);
                int did= rs.getInt(2);
                String d= ""+did;
                q="SELECT name,PICTURE from patient where patient_id =?";
                stmt= db.conn.prepareStatement(q);
                stmt.setString(1,uid);
                rs= stmt.executeQuery();
                if(rs.next())
                {
                    p.name=rs.getString(1);
                    Blob b;
                    b=  rs.getBlob(2);
                    p.pic=b.getBytes(1, (int) b.length());
                    q="SELECT name from employee where staff_id =?";
                    stmt= db.conn.prepareStatement(q);
                    stmt.setString(1,d);
                    rs= stmt.executeQuery();
                    if(rs.next())
                    {
                        p.dname=rs.getString(1);
                    }
                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        session.setAttribute("ppp",p);
        RequestDispatcher rd = request.getRequestDispatcher("seerecord.jsp");
        rd.forward(request, response);


    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
