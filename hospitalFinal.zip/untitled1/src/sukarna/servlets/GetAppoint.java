/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sukarna.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import sukarna.db.DataAccess;
import sukarna.models.CartItem;

/**
 *
 * @author samsung
 */
public class GetAppoint extends HttpServlet {

    int did,pid,s,j,cnt;
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        String dname = request.getParameter("dname");
        String date = request.getParameter("bdate");
        String uid= (String) session.getAttribute("username");
        System.out.println(dname+ "POP"+ uid +"kop ");
        if(dname==null)
        {
            RequestDispatcher rd = request.getRequestDispatcher("Appoints.jsp");
            rd.forward(request, response);
        }
        //String query = "SELECT COUNT(*) FROM Appoints WHERE Doctor_ID= ?";
        String query1= "Select  Staff_Id FROM EMPLOYEE where NAME = ?";
        //String query2= "Select  Patient_ID FROM patient where NAME = ?";
        DataAccess db = new DataAccess();
        PreparedStatement stmt = null;
        try {
            stmt = db.conn.prepareStatement(query1);
            stmt.setString(1,dname );
            ResultSet rs = stmt.executeQuery();
            if(rs.next()){
                did= rs.getInt(1);
                String a= ""+did;
                int i = db.getappoint(a);
                System.out.println(a);
                if(i==0)
                {
                    RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
                    rd.forward(request, response);

                }
                else{

                    String q= "INSERT into Appoints(Patient_id,Doctor_id,Receptionist_id,APPOINT_DATE,Serial_no) VALUES (?,?,?,?,? )";
                    stmt = db.conn.prepareStatement(q);
                    String k= ""+did;
                    String m= ""+pid;
                    stmt.setString(1,uid);
                    stmt.setString(2,a);
                    stmt.setString(3,"116");
                    m= ""+cnt;
                    Date d= Date.valueOf(date);
                    stmt.setDate(4, d);
                    stmt.setString(5,m);


                    rs= stmt.executeQuery();
                }
                /*stmt = db.conn.prepareStatement(query);
                stmt.setString(1,a);
                rs=stmt.executeQuery();
                if(rs.next()){
                    cnt=rs.getInt(1);
                    if(j>7){
                        RequestDispatcher rd = request.getRequestDispatcher("Error.jsp");
                        rd.forward(request, response);
                    }
                    else{

                        String q= "INSERT into Appoints(Patient_id,Doctor_id,Receptionist_id,Serial_no) VALUES (?,?,?,? )";
                        stmt = db.conn.prepareStatement(q);
                        String k= ""+did;
                        String m= ""+pid;
                        stmt.setString(1,m);
                        stmt.setString(2,k);
                        stmt.setString(3,"111");
                        m= ""+cnt;
                        stmt.setString(4,m);

                        rs= stmt.executeQuery();
                    }

                }
                else
                {
                    String q= "INSERT into Appoints(Patient_id,Doctor_id,Receptioist_id,Serial_no) VALUES (?,?,?,? )";
                    stmt = db.conn.prepareStatement(q);
                    String k= ""+did;
                    String m= ""+pid;
                    stmt.setString(1,m);
                    stmt.setString(2,k);
                    stmt.setString(3,"111");
                    m= ""+cnt;
                    stmt.setString(4,m);

                    rs= stmt.executeQuery();
                }*/

            }
            else {
                RequestDispatcher rd = request.getRequestDispatcher("doctorn.jsp");
                rd.forward(request, response);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }


        //String product = request.getParameter("product");
        //String amount = request.getParameter("amount");
        //



        RequestDispatcher rd = request.getRequestDispatcher("done.jsp");
        rd.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("post");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
