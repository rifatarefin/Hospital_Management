package sukarna.servlets;

import javax.servlet.http.HttpServlet;

/**
 * Created by Shusmoy on 12/7/2016.
 */
public class Done extends HttpServlet {
}
