package sukarna.servlets;

import sukarna.db.DataAccess;
import sukarna.models.CartItem;
import sukarna.models.patient;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by Shusmoy on 12/7/2016.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

public class giverecord extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();

        ArrayList<patient> patients = new ArrayList<>();
        String query = "select name, patient_id from patient where patient_id in (select patient_id from Appoints) ";
        DataAccess db = new DataAccess();
        PreparedStatement stmt = null;
        try {
            stmt = db.conn.prepareStatement(query);
            ResultSet rs1 = stmt.executeQuery();
            ResultSet rs;
            while(rs1.next())
            {

                System.out.println(rs1.getString(1)+ " + " + rs1.getInt(2));

                int id=rs1.getInt(2);

               String a= ""+id;
               String q="select Doctor_id from appoints where patient_id = ? ";
               String qe=" select record_id from patient_record where patient_id = ?";
               stmt= db.conn.prepareStatement(q);
               stmt.setString(1,a);
                ResultSet rs2;
               rs2=stmt.executeQuery();
               while(rs2.next()) {
                   int d = rs2.getInt(1);
                   a = "" + d;
                   System.out.println(a);
                   q = "select Name from employee where staff_id = ? ";
                   stmt=db.conn.prepareStatement(q);
                   stmt.setString(1, a);
                   patient p = new patient();
                   p.name=rs1.getString(1);
                   p.pid=rs1.getInt(2);
                   System.out.println(p.pid);
                   rs = stmt.executeQuery();

                   if (rs.next()) {
                       System.out.println(rs.getString(1));
                       p.dname = rs.getString(1);
                       stmt= db.conn.prepareStatement(qe);
                       String n= ""+p.pid;
                       stmt.setString(1,n);
                       rs= stmt.executeQuery();
                       if (rs.next())
                       {
                           p.appoint=""+rs.getInt(1);
                       }
                   }
                   patients.add(p);
               }
                System.out.println("hereppo");

                System.out.println(rs2.next());
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        ArrayList<patient> patient2 = new ArrayList<>();
        String quer = "select name, patient_id from patient where patient_id in (select patient_id from admitted) ";
        try {
            stmt = db.conn.prepareStatement(quer);
            ResultSet rs1 = stmt.executeQuery();
            ResultSet rs;
            while(rs1.next())
            {

                System.out.println(rs1.getString(1)+ " + " + rs1.getInt(2));
                patient p = new patient();
                p.name=rs1.getString(1);
                p.pid=rs1.getInt(2);
                System.out.println(p.pid);
                String a= ""+p.pid;
                String q="select ward_id from admitted where patient_id = ? ";
                stmt= db.conn.prepareStatement(q);
                stmt.setString(1,a);
                rs=stmt.executeQuery();
                if(rs.next()) {
                    int d = rs.getInt(1);
                    a = "" + d;
                    System.out.println(a);
                    q = "select room_no from ward where ward_id = ? ";
                    stmt=db.conn.prepareStatement(q);
                    stmt.setString(1, a);

                    rs = stmt.executeQuery();

                    if (rs.next()) {
                        System.out.println(rs.getString(1));
                        p.dname = rs.getString(1);
                        String qe=" select record_id from patient_record where patient_id = ?";
                        stmt= db.conn.prepareStatement(qe);
                        String n= ""+p.pid;
                        stmt.setString(1,n);
                        rs= stmt.executeQuery();
                        if (rs.next())
                        {
                            p.appoint=""+rs.getInt(1);
                        }
                    }
                }
                System.out.println("hereppo");
                patient2.add(p);
                System.out.println(rs1.next());
            }


        } catch (SQLException e) {
            e.printStackTrace();
        }

        //String product = request.getParameter("product");
        //String amount = request.getParameter("amount");
        //


        session.setAttribute("patient", patients);

        session.setAttribute("ward", patient2);

        RequestDispatcher rd = request.getRequestDispatcher("urecord.jsp");
        rd.forward(request, response);

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("post");
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

