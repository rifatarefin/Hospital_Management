package sukarna.servlets;

import sukarna.db.DataAccess;
import sukarna.models.CartItem;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 * Created by Rifat Arefin on 14-Dec-16.
 */
@WebServlet(name = "MedicineAdd")
public class MedicineAdd extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        String medname = request.getParameter("medname");
        String pid = (String) session.getAttribute("username");
        String quantity = request.getParameter("quantity");
        if(quantity==null)quantity="1";
        String recid = null,medid=null;
        if(pid==null)
        {
            RequestDispatcher rd = request.getRequestDispatcher("addmedicine.jsp");
            rd.forward(request, response);
        }

        DataAccess db = new DataAccess();
        PreparedStatement stmt = null;
        try {
            recid=db.proc_get_recordid(pid);
            System.out.println(recid);
        } catch (SQLException e) {
            e.printStackTrace();
        }

        System.out.println(recid);

        if(recid!="-999")
        {

            String q3="SELECT MEDICINE_ID FROM MEDICINE WHERE MEDICINE_NAME=?";
            try {
                stmt = db.conn.prepareStatement(q3);
                stmt.setString(1,medname);
                ResultSet rs = stmt.executeQuery();
                if(rs.next()) medid=rs.getString(1);
                System.out.println(medid);
            } catch (SQLException e) {
                e.printStackTrace();
            }
            String q2="insert into BUYS values(?,?,?,?)";
            try {
                stmt = db.conn.prepareStatement(q2);
                stmt.setString(1,pid);
                stmt.setString(2,medid);
                stmt.setString(3,recid);
                stmt.setString(4,quantity);
                ResultSet rs = stmt.executeQuery();

            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        ArrayList<CartItem> productList = new ArrayList<CartItem>();
        String query = "SELECT MEDICINE_NAME, QUANTITY FROM MEDICINE m join BUYS b ON (m.MEDICINE_ID=b.MEDICINE_ID)  WHERE RECORD_ID=?";

        try {
            stmt = db.conn.prepareStatement(query);
            stmt.setString(1,recid);
            ResultSet rs = stmt.executeQuery();
            while(rs.next())
            {
                System.out.println(rs.getString(1)+ " + " + rs.getInt(2));
                CartItem item = new CartItem(rs.getString(1),rs.getInt(2));
                productList.add(item);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        session.setAttribute("cart", productList);
        RequestDispatcher rd = request.getRequestDispatcher("medSuccess.jsp");
        rd.forward(request, response);
//        if(count==1)
//        {
//            RequestDispatcher rd = request.getRequestDispatcher("index.html");
//            rd.forward(request, response);
//        }
//        else
//        {
//            RequestDispatcher rd = request.getRequestDispatcher("createAccount.jsp");
//            rd.forward(request, response);
//        }
    }
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);


    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        processRequest(request,response);
    }
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
