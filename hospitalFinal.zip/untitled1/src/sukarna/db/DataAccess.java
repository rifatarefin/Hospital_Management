/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sukarna.db;

import sukarna.models.employee;

import javax.servlet.ServletInputStream;
import java.io.InputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author samsung
 */
public class DataAccess 
{
    String dbURL = "jdbc:oracle:thin:@//localhost:1521/XE";
    String username = "hospital";
    String password = "1234";

    public  Connection conn = null;
    public DataAccess()
    {
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection(dbURL, username, password);
            if(conn!=null) System.out.println("Connection successfully established.");
            else System.out.println("Could not establish connection");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }



    
   
    public boolean existUser(String username,String password)
    {
        try
        {
            String query = "select * from passuser where id = ? and password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            return rs.next();
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }
        
        
        
    }
    public boolean userpatient(String username,String password)
    {
        try
        {
            String query = "select * from passuser where id = ? and password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                query = "select * from patient where patient_id= ?";
                stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                rs = stmt.executeQuery();
                if(rs.next())
                {
                    return true;
                }
            }
            return false;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }

    }

    public boolean userdoctor(String username,String password)
    {
        try
        {
            String query = "select * from passuser where id = ? and password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                query = "select * from doctor where doctor_id= ?";
                stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                rs = stmt.executeQuery();
                if(rs.next())
                {
                    return true;
                }
            }
            return false;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }

    }

    public boolean userrecep(String username,String password)
    {
        try
        {
            String query = "select * from passuser where id = ? and password = ?";
            PreparedStatement stmt = conn.prepareStatement(query);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();
            if(rs.next())
            {
                query = "select * from receptionist where receptionist_id= ?";
                stmt = conn.prepareStatement(query);
                stmt.setString(1, username);
                rs = stmt.executeQuery();
                if(rs.next())
                {
                    return true;
                }
            }
            return false;
        }
        catch(Exception e)
        {
            e.printStackTrace();
            return false;
        }

    }
    public employee recep(String username)
    {
        try
        {
            String query = "select NAME,Staff_id, gender, Employee_type,PICTURE from employee where staff_id = ?";
            CallableStatement stmt = conn.prepareCall(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            employee e = new employee();
            if(rs.next())
            {
                e.staff_id=rs.getInt(2);
                e.name= rs.getString(1);
                e.gender= rs.getString(3);
                e.etype= rs.getString(4);
                e.join= "8-9-10";
                Blob b;
                b=rs.getBlob(5);
                e.pic=b.getBytes(1, (int) b.length());
                return e;


            }
            return  null;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }

    }
    public int mbill(String uid)
    {
        String q="Select medicine_id,quantity from buys where patient_id =?";
        int t=0;
        try {
            PreparedStatement stmt = conn.prepareStatement(q);
            stmt.setString(1,uid);
            ResultSet rs= stmt.executeQuery();
            while (rs.next())
            {
                int mid= rs.getInt(1);
                int qu= rs.getInt(2);
                q="Select price from MEDICINE where MEDICINE_ID =?";
                String m= ""+mid;
                stmt= conn.prepareStatement(q);
                stmt.setString(1,m);
                ResultSet rs1= stmt.executeQuery();
                if(rs1.next())
                {
                    t= t+ qu*rs1.getInt(1);

                }

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return  t;
    }
    public employee doctor(String username)
    {
        try
        {
            String query = "select NAME,Staff_id, gender, Employee_type from employee where staff_id = ?";
            CallableStatement stmt = conn.prepareCall(query);
            stmt.setString(1, username);
            ResultSet rs = stmt.executeQuery();
            employee e = new employee();
            if(rs.next())
            {
                e.staff_id=rs.getInt(2);
                e.name= rs.getString(1);
                e.gender= rs.getString(3);
                e.etype= rs.getString(4);
                e.join= "8-9-10";
                return e;


            }
            return  null;

        }
        catch(Exception e)
        {
            e.printStackTrace();
            return null;
        }

    }


    public boolean urecord(String pid,String rid,String did) throws SQLException {
        String q = "INSERT into patient_record(patient_id,record_id,doctor_id) values(?,?,?)";
        PreparedStatement stmt= conn.prepareStatement(q);
        stmt.setString(1,pid);
        stmt.setString(2,rid);
        stmt.setString(3,did);
        ResultSet rs=stmt.executeQuery();
        return rs.next();

    }
    public boolean precord(String rid,String pr) throws SQLException {
        String q = "UPDATE patient_record SET description = ? WHERE record_ID = ? ";
        PreparedStatement stmt= conn.prepareStatement(q);
        stmt.setString(1,pr);
        stmt.setString(2,rid);
        ResultSet rs=stmt.executeQuery();
        return rs.next();

    }
    public boolean drecord(String pid) throws SQLException {
        String q= "DELETE FROM appoints WHERE patient_id = ? ";
        PreparedStatement stmt= conn.prepareStatement(q);
        stmt.setString(1,pid);

        ResultSet rs=stmt.executeQuery();
        return rs.next();

    }
    public boolean darecord(String pid) throws SQLException {
        String q= "DELETE FROM admitted WHERE patient_id = ? ";
        PreparedStatement stmt= conn.prepareStatement(q);
        stmt.setString(1,pid);

        ResultSet rs=stmt.executeQuery();
        return rs.next();

    }


    public int createpatient(String name,String gen, String pass, String add,String bdate,InputStream pic) {

        try {
            //String q= "INSERT into patient(NAME ,gender,Address) VALUES (?,?,?)";
            //String q ="{ call INSERTPATIENT(?,?,?) }";
            //{ ? = call get_appoint(?) }
            //CallableStatement statement = conn.prepareCall(q);
            //statement.setString(1,name);
            //statement.setString(2,gen);
            //statement.setString(3,add);
            ResultSet rs;
            int i= insertpatient(name,gen,add,bdate,pic);
            PreparedStatement stmt;
            //stmt.setString(1,name);
            //stmt.setString(2,gen);
            //stmt.setString(3,add);
            //stmt.execute();
            //rs= stmt.executeQuery();
            //System.out.println(statement.execute());
            if( i!=0)
            {
                String q= "select patient_id FROM patient WHERE name= ?";
                stmt = conn.prepareStatement(q);
                stmt.setString(1,name);

                rs= stmt.executeQuery();
                if( rs.next()) {
                    String qw=""+rs.getInt(1);
                    int cnt= rs.getInt(1);
                    q = "INSERT into passuser(Id,password) VALUES (?,?)";
                    stmt = conn.prepareStatement(q);
                    stmt.setString(1, qw);
                    stmt.setString(2, pass);
                    rs = stmt.executeQuery();
                    if (rs.next()) {
                        return cnt;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int createemployee(String name,String gen, String pass, String type, String add, InputStream f) {

        try {
            String q= "INSERT into employee(NAME ,gender,employee_type,Address,PICTURE) VALUES (?,?,?,?,? )";
            PreparedStatement stmt = conn.prepareStatement(q);
            stmt.setString(1,name);
            stmt.setString(2,gen);
            stmt.setString(3,type);
            stmt.setString(4,add);
            stmt.setBlob(5,f);
            ResultSet rs = stmt.executeQuery();

            if(rs.next())
            {
                q= "select Staff_id FROM employee WHERE name= ?";
                stmt = conn.prepareStatement(q);
                stmt.setString(1,name);
                rs= stmt.executeQuery();

                if(rs.next()) {
                    String qw=""+rs.getInt(1);
                    int cnt= rs.getInt(1);
                    q = "INSERT into passuser(Id,password) VALUES (?,?)";
                    stmt = conn.prepareStatement(q);

                    stmt.setString(1, qw);
                    stmt.setString(2, pass);
                    rs = stmt.executeQuery();
                    if (rs.next()) {
                        return cnt;
                    }
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }

    public int bill(String id) throws SQLException {
        int bil=0;
        String sql = "{ ? = call get_abill(?) }";
        CallableStatement statement = conn.prepareCall(sql);
        statement.setString(2,id);
        statement.registerOutParameter(1, java.sql.Types.INTEGER);

        statement.execute();
        //this is the main line
         bil = statement.getInt(1);

        System.out.println( bil);
        return bil;
    }
    public int getappoint(String eid) throws SQLException {
        String sql = "{ ? = call get_appoint(?) }";
        CallableStatement statement = conn.prepareCall(sql);
        statement.setString(2,eid);
        statement.registerOutParameter(1, java.sql.Types.INTEGER);

        statement.execute();
        //this is the main line
        int id = statement.getInt(1);
        System.out.println( id);
        return id;
    }

    public int getADMITTED(String eid) throws SQLException {
        String sql = "{ ? = call get_admitted(?) }";
        CallableStatement statement = conn.prepareCall(sql);
        statement.setString(2,eid);
        statement.registerOutParameter(1, java.sql.Types.INTEGER);

        statement.execute();
        //this is the main line
        int id = statement.getInt(1);
        System.out.println( id);
        return id;
    }
    public int insertpatient(String n,String g, String a,String bd,InputStream pic)
    {
        String sql = "{ call insertpatient(?,?,?,?,?,?) }";
        CallableStatement statement = null;
        int id=0;
        try {
            statement = conn.prepareCall(sql);
            statement.setString(1, n);
            statement.setString(2, g);
            statement.setString(3, a);
            statement.setBlob(5, pic);
            //statement.setString(4, bd);
            if(bd!="") {
                System.out.println(bd+"pp");
                Date d = Date.valueOf(bd);
                statement.setDate(4, d);
            }
            else {statement.setDate(4,null);
                System.out.println("sssssssss");}
            System.out.println(bd);
            statement.registerOutParameter(6, java.sql.Types.INTEGER);
            statement.execute();
            //this is the main line
            id = statement.getInt(6);
            System.out.println( id);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return id;
    }
    public String proc_get_recordid(String pid) throws SQLException {
        String sql = "{ call proc_get_recordid(?,?) }";
        CallableStatement statement = conn.prepareCall(sql);
        statement.setString(1,pid);
        statement.registerOutParameter(2, java.sql.Types.INTEGER);

        statement.execute();
        //this is the main line
        String id = statement.getString(2);
        System.out.println("sfqw"+id);
        return id;
    }

    
/*
//Call function sample:
    
    String sql = "{ ? = call FUNCT_PERSON(?,?) }";
    CallableStatement statement = connection.prepareCall(sql);
    statement.setString(2,username);
    statement.setString(3,password);
    statement.registerOutParameter(1, java.sql.Types.INTEGER);  

    statement.execute();   
    //this is the main line
    long id = statement.getLong(1);
    if (id > 0) {
        //proceed to another page
    } else {
        //Go back to the login page
    }*/
    
 /*
    String sql = "{ call PROC_PERSON(?,?,?) }";
    CallableStatement statement = connection.prepareCall(sql);
    statement.setString(2,username);
    statement.setString(3,password);
    statement.registerOutParameter(1, java.sql.Types.INTEGER);  

    statement.execute();   
    //this is the main line
    long id = statement.getLong(1);
    if (id > 0) {
        //proceed to another page
    } else {
        //Go back to the login page
    }*/ 
}
