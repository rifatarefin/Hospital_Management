package sukarna.models;

import org.omg.CORBA.portable.OutputStream;

import java.io.InputStream;

/**
 * Created by Shusmoy on 12/12/2016.
 */
public class patient {
    public String name;
    public String appoint;
    public int pid;
    public String dname;
    public String des;
    public int rid;
    public int did;
    public byte[] pic=null;
    public String getDes() {
        return des;
    }

    public int getRid() {
        return rid;
    }

    public void setDes(String des) {

        this.des = des;
    }

    public void setRid(int rid) {
        this.rid = rid;
    }


    public patient() {

    }

    public void setAppoint(String appoint) {
        this.appoint = appoint;
    }

    public void setPid(int pid) {
        this.pid = pid;
    }

    public void setDname(String dname) {
        this.dname = dname;
    }

    public String getAppoint() {

        return appoint;
    }

    public int getPid() {
        return pid;
    }

    public String getDname() {
        return dname;
    }

    public patient(String name)
    {
        this.name=name;
    }
    public String getName(){return this.name;}
    public void setName(String name){this.name= name;}
}
