package sukarna.models;

/**
 * Created by Rifat Arefin on 15-Dec-16.
 */
public class bill {
    public int mbill=0;
    public int abill=0;
    public int tbill=0;

    public bill()
    {

    }
}
