package sukarna.models;

/**
 * Created by Shusmoy on 12/8/2016.
 */
public class Ward {
    int room;
    int amount;
    String type;

    public Ward(int product, int amount,String type) {
        this.room = product;
        this.amount = amount;
        this.type=type;

    }


    public String gettype() {
        return type;
    }

    public void settype(String product) {
        this.type = product;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public int getRoom(){ return room;}

    public void setRoom(int room){ this.room=room; }
}
