package sukarna.models;

/**
 * Created by Shusmoy on 12/12/2016.
 */
public class employee {
    public String name;
    public int staff_id;
    public String gender;
    public String join;
    public String etype;
    public byte[] pic=null;

    public employee(String name, int staff_id, String gender, String join, String etype) {
        this.name = name;
        this.staff_id = staff_id;
        this.gender = gender;
        this.join = join;
        this.etype = etype;
    }

    public String getName() {
        return name;
    }

    public int getStaff_id() {
        return staff_id;
    }

    public String getGender() {
        return gender;
    }

    public String getJoin() {
        return join;
    }

    public String getEtype() {
        return etype;
    }

    public employee() {
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setStaff_id(int staff_id) {
        this.staff_id = staff_id;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setJoin(String join) {
        this.join = join;
    }

    public void setEtype(String etype) {
        this.etype = etype;
    }
}
