package hospital;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author samsung
 */
public class Main
{
    String dbURL = "jdbc:oracle:thin:@localhost:1521:ORCL";
    String username = "HR";
    String password = "hr";
    String name1= "first_name";
    String name2= "salary";
    

    Connection conn = null;
    public Main()
    {
        try
        {
            Class.forName("oracle.jdbc.OracleDriver");
            conn = DriverManager.getConnection(dbURL, username, password);
            if(conn!=null) System.out.println("Connection successfully established.");
            else System.out.println("Could not establish connection");
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
    public List<String> getEmployeeNames()
    {
        List<String> employeeNames = new ArrayList<String>();
        String selectStatement = "select "+name1+","+name2+" from employees";
        try
        {    
            PreparedStatement stmt = conn.prepareStatement(selectStatement);
            ResultSet rs = stmt.executeQuery();
            while(rs.next())
            {
                String first = rs.getString("first_name");
                int last = rs.getInt("salary");
                String name = first + " " + last;
                employeeNames.add(name);
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
        
        return employeeNames;
    }

   public static void main(String[] args)
   {
       Main m=new Main();
        int i= m.getEmployeeNames().size();
        for (int j=0;j<i;j++){
                System.out.println(m.getEmployeeNames().get(j)); 
        }
       
   }
            
}