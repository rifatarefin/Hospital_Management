package hospital;

public class Controller {
}
